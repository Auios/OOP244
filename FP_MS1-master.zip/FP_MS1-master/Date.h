// add your information in here, 
// use dateTester.h comments an a template

#ifndef SICT_DATE_H__
#define SICT_DATE_H__
#include <iostream>
namespace sict{


  class Date{
  private:
 
    int value()const;

  public:
    void set();
    int mdays()const;



  };



}
#endif