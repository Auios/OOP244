#ifndef SICT_POS_H__
#define SICT_POS_H__

#define TAX (0.13)
#define MAX_SKU_LEN (7)

#define MIN_YEAR (2000)
#define MAX_YEAR (2030)
#define MIN_HOUR (0)
#define MAX_HOUR (23)
#define MIN_MIN  (0)
#define MAX_MIN  (59)

#define MAX_NO_ITEMS (2000)
#endif