# Final Project Milestone 5. 
Due date for the Final project is Wednesday Dec 09: 23:59. You will lose 10% for late submissions<br /> 
## Sample program:<br />
<pre>
$ ~fardad.soleimanloo/fp &lt;ENTER&gt;
</pre>
## Submission instructions:
Submit your project using this commant:
<pre>
$ ~your.professor/submit pos &lt;ENTER&gt;
</pre>
Demonstrate your work by going through these options in the order stated below.
* A: 1- list the items
* B: 2- Add Perishable Item<br /> 
Add a perishable item with following information:
<pre>
Sku: 5678
Name: Butter
price: 3.25
Taxed: n
Quantity: 20
Expiry date (YYYY/MM/DD): 2015/12/12
</pre>
* C: 4- Update item Quantity <br />
Update quantity of the item with sku number :1234 <br />
Add "2" to its quantity.
* D: 5- Show Item<br />
Show Item with sku 1234
* E: 6- POS
Sell the following items:
<pre>
1234
4567
4567
4567
&lt;ENTER&gt;
<pre />
* F: 0- exit Program

## Open Submission
On Wednesday  Dec 16 noon, you can submit your working assignment without passing the output test. But you will lose 30% at this time.
## Submissions after Fri. Dec 18, 23:59
You must submit your work before Fri Dec 18, 23:59 <br />
Any submission after this time will cause a DNC (Did Not Complete) mark in transcript and a new due date set with a maximum mark of 49%.
