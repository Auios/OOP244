#ifndef SICT_w1_H_
#define SICT_w1_H_

const char* printMsg = "Finished... Exiting\n";	//End message
const char* errMsg = "Try again\n";	//Error message
const char* cancelMsg = "Order cancelled - Start again\n";	//Cancel message

#endif