#ifndef SICT_CHECKOUT_H_
#define SICT_CHECKOUT_H_

//Functions
int checkout();			// Display menu and return selection

#endif